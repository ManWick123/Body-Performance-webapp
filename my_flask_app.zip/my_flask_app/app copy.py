import pickle

# Load the trained model
model = pickle.load(open('C:/Users/manul/Desktop/body_perf_final/my_flask_app/body_perf_pickle_file.pkl', 'rb'))

input_data = [27.00, 1.00, 21.30, 54.90, 18.40, 60.00, 217.00, 25.34]
        
# Use loaded model to make prediction
prediction = model.predict([input_data])[0]
prediction_prob = model.predict_proba([input_data])[0]

# printing the result
print(prediction)
print(round(prediction_prob[0]*100,4))